package com.example.weeklytaskplannerapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "tasks.db";
    private static final int DATABASE_VERSION = 3;
    private static final String TABLE_TASKS = "tasks";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DAY = "day";
    private static final String COLUMN_TASK = "task";
    private static final String COLUMN_TIMESTAMP = "timestamp";
    private static final String COLUMN_COMPLETED = "completed";
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_TASKS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DAY + " TEXT,"
                + COLUMN_TASK + " TEXT,"
                + COLUMN_TIMESTAMP + " TEXT,"
                + COLUMN_COMPLETED + " INTEGER DEFAULT 0"
                + ")";
        db.execSQL(CREATE_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        onCreate(db);
    }
    public void addTask(String day, String task) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DAY, day);
        values.put(COLUMN_TASK, task);
        String currentTime = java.text.DateFormat.getDateTimeInstance().format(new
                java.util.Date());
        values.put(COLUMN_TIMESTAMP, currentTime);
        values.put(COLUMN_COMPLETED, 0);
        db.insert(TABLE_TASKS, null, values);
        db.close();
    }
    public ArrayList<TaskModel> getTasks(String day) {
        ArrayList<TaskModel> tasks = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TASKS,
                new String[]{COLUMN_TASK, COLUMN_TIMESTAMP,
                        COLUMN_COMPLETED},
                COLUMN_DAY + "=?",
                new String[]{day},
                null, null, null);
        if (cursor.moveToFirst()) {
            do {
                String task = cursor.getString(0);
                String timestamp = cursor.getString(1);
                boolean completed = cursor.getInt(2) == 1;
                tasks.add(new TaskModel(task, timestamp, completed));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return tasks;
    }
    public void deleteTask(String day, String task) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_TASKS, COLUMN_DAY + "=? AND " + COLUMN_TASK +
                "=?", new String[]{day, task});
        db.close();
    }
    public void updateTask(String day, String oldTask, String newTask) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TASK, newTask);
        String newTime = java.text.DateFormat.getDateTimeInstance().format(new
                java.util.Date());
        values.put(COLUMN_TIMESTAMP, newTime);
        db.update(TABLE_TASKS, values, COLUMN_DAY + "=? AND " +
                COLUMN_TASK + "=?", new String[]{day, oldTask});
        db.close();
    }
    public void setTaskCompleted(String day, String task, boolean completed) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COMPLETED, completed ? 1 : 0);
        db.update(TABLE_TASKS, values, COLUMN_DAY + "=? AND " +
                COLUMN_TASK + "=?", new String[]{day, task});
        db.close();
    }
}

