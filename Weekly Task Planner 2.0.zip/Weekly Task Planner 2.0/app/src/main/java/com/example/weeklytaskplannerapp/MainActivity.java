package com.example.weeklytaskplannerapp;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private ListView listViewDays;
    private String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday", "Saturday"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) {
            getSupportActionBar().show();
            getSupportActionBar().setTitle(getString(R.string.app_name));
        }
        listViewDays = findViewById(R.id.listViewDays);
        DayAdapter adapter = new DayAdapter(this, days);
        listViewDays.setAdapter(adapter);
        listViewDays.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedDay = days[position];
                Intent intent = new Intent(MainActivity.this, TaskActivity.class);
                intent.putExtra("day", selectedDay);
                startActivity(intent);
            }
        });
    }
}