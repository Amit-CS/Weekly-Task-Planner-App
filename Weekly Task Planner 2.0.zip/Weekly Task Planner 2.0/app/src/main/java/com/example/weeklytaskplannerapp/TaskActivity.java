package com.example.weeklytaskplannerapp;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
public class TaskActivity extends AppCompatActivity {
    private TextView textViewDay;
    private EditText editTextTask;
    private Button buttonAddTask, buttonClearTasks;
    private ListView listViewTasks;
    private SQLiteDatabase database;
    private ArrayList<TaskItem> taskList;
    private TaskAdapter adapter;
    private String selectedDay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);
        //  Hide ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        textViewDay = findViewById(R.id.textViewDay);
        editTextTask = findViewById(R.id.editTextTask);
        buttonAddTask = findViewById(R.id.buttonAddTask);
        buttonClearTasks = findViewById(R.id.buttonClearTasks);
        listViewTasks = findViewById(R.id.listViewTasks);
        Intent intent = getIntent();
        selectedDay = intent.getStringExtra("day");
        textViewDay.setText(selectedDay + " Tasks");
        database = openOrCreateDatabase("WeeklyTasksDB", MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS tasks(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "day TEXT, " +
                "task TEXT, " +
                "timestamp TEXT, " +
                "completed INTEGER DEFAULT 0)");
        try {
            database.execSQL("ALTER TABLE tasks ADD COLUMN completed INTEGER DEFAULT 0");
        } catch (Exception ignored) {}
        taskList = new ArrayList<>();
        adapter = new TaskAdapter(this, taskList, database);
        listViewTasks.setAdapter(adapter);
        loadTasks();
        // Add Task
        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskText = editTextTask.getText().toString().trim();
                if (!taskText.isEmpty()) {
                    String timestamp = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a",
                            Locale.getDefault()).format(new Date());
                    ContentValues values = new ContentValues();
                    values.put("day", selectedDay);
                    values.put("task", taskText);
                    values.put("timestamp", timestamp);
                    values.put("completed", 0);
                    database.insert("tasks", null, values);
                    editTextTask.setText("");
                    loadTasks();
                }
            }
        });
        //  Clear Tasks
        buttonClearTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database.delete("tasks", "day=?", new String[]{selectedDay});
                loadTasks();
            }
        });
    }
    private void loadTasks() {
        taskList.clear();
        Cursor cursor = database.rawQuery(
                "SELECT task, timestamp, completed, day FROM tasks WHERE day=?",
                new String[]{selectedDay}
        );
        if (cursor.moveToFirst()) {
            do {
                String task = cursor.getString(0);
                String timestamp = cursor.getString(1);
                boolean completed = cursor.getInt(2) == 1;
                String day = cursor.getString(3);
                taskList.add(new TaskItem(task, timestamp, completed, day));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
}
