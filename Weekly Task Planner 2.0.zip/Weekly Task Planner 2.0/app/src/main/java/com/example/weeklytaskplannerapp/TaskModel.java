package com.example.weeklytaskplannerapp;
public class TaskModel {
    String task;
    String timestamp;
    boolean completed;
    public TaskModel(String task, String timestamp, boolean completed) {
        this.task = task;
        this.timestamp = timestamp;
        this.completed = completed;
    }
}