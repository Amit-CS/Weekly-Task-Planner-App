package com.example.weeklytaskplannerapp;
public class TaskItem {
    private String task;
    private String timestamp;
    private boolean completed;
    private String day;
    public TaskItem(String task, String timestamp, boolean completed, String day) {
        this.task = task;
        this.timestamp = timestamp;
        this.completed = completed;
        this.day = day;
    }
    public String getTask() { return task; }
    public String getTimestamp() { return timestamp; }
    public boolean isCompleted() { return completed; }
    public String getDay() { return day; }
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
}

