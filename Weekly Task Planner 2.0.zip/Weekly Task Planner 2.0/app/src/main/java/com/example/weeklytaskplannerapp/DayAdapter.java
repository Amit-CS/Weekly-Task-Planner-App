package com.example.weeklytaskplannerapp;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
public class DayAdapter extends ArrayAdapter<String> {
    private Context context;
    private String[] days;
    public DayAdapter(Context context, String[] days) {
        super(context, R.layout.day_item, R.id.textViewDayItem, days);
        this.context = context;
        this.days = days;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        TextView textView = view.findViewById(R.id.textViewDayItem);
        int color;
        switch (days[position]) {
            case "Sunday": color = ContextCompat.getColor(context, R.color.sunday);
                break;
            case "Monday": color = ContextCompat.getColor(context,
                    R.color.monday); break;
            case "Tuesday": color = ContextCompat.getColor(context,
                    R.color.tuesday); break;
            case "Wednesday": color = ContextCompat.getColor(context,
                    R.color.wednesday); break;
            case "Thursday": color = ContextCompat.getColor(context,
                    R.color.thursday); break;
            case "Friday": color = ContextCompat.getColor(context, R.color.friday);
                break;
            case "Saturday": color = ContextCompat.getColor(context,
                    R.color.saturday); break;
            default: color = ContextCompat.getColor(context,
                    android.R.color.darker_gray);
        }
        textView.setBackgroundColor(color);
        return view;
    }
}
