package com.example.weeklytaskplannerapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.util.ArrayList;
public class TaskAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<TaskItem> taskList;
    private SQLiteDatabase database;
    public TaskAdapter(Context context, ArrayList<TaskItem> taskList,
                       SQLiteDatabase database) {
        this.context = context;
        this.taskList = taskList;
        this.database = database;
    }
    @Override
    public int getCount() {
        return taskList.size();
    }
    @Override
    public Object getItem(int position) {
        return taskList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.item_task, parent, false);
        }
        CheckBox checkBox = convertView.findViewById(R.id.checkBoxComplete);
        TextView textTask = convertView.findViewById(R.id.textTask);
        TextView textTimestamp = convertView.findViewById(R.id.textTimestamp);
        TaskItem task = taskList.get(position);
        // Set data
        textTask.setText(task.getTask());
        textTimestamp.setText(task.getTimestamp());
        // Prevent unwanted triggers
        checkBox.setOnCheckedChangeListener(null);
        checkBox.setChecked(task.isCompleted());
        // Checkbox listener
        checkBox.setOnCheckedChangeListener(new
        CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                task.setCompleted(isChecked);
                // Update database
                ContentValues values = new ContentValues();
                values.put("completed", isChecked ? 1 : 0);
                database.update("tasks", values,
                        "day=? AND task=? AND timestamp=?",
                        new String[]{task.getDay(), task.getTask(), task.getTimestamp()});
            }
        });
        return convertView;
    }
}